﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class Boss : MonoBehaviour {

    public GameObject boss;
    public int bossHealth = 20;
    public float speed;
    private bool right = true;
    private bool down = true;
    private Transform playerPos;
    private Player player;
    int passed = 0;
    
    void Start()
    {
        
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        playerPos = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        //laser = GameObject.FindGameObjectWithTag("Laser").GetComponentn<Laser>();
    }

    void Update()
    {
        if (down)
        {
            transform.Translate(Vector2.down * speed * Time.deltaTime);
        }
        else
        {
            transform.Translate(-Vector2.down * speed * Time.deltaTime);
        }

        if (transform.position.y >= 51)
        {
            down = true;
        }
        if (transform.position.y <= 38)
        {
            down = false;
        }

        if (passed == 1)
        {
            transform.position = Vector2.MoveTowards(transform.position, playerPos.position, speed * Time.deltaTime);
        }
    
        


    }
    private void OnTriggerEnter2D(Collider2D other)
    {

        passed = 1;
        if (other.CompareTag("Player"))
        {// Losing Health
            player.health--;
            
            Debug.Log(player.health);
            //Destroy(gameObject);
        }
        if (other.CompareTag("Projectile"))
        {
            bossHealth--;
        }
        if (bossHealth == 0)
        {
            Destroy(gameObject);
            
            
        }
    
    }
}
