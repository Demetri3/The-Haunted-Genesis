﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//new using statements
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;

public class GameController : MonoBehaviour {

    [Header("UI setting")]
    public Text healthText;
    public Text gameOverText;
    public Text restartText;
    public Text winText;
    public Text noKeyText;

    private bool restart;
    
    private Player player;
    

    // Use this for initialization
    void Start() {
        
        restart = false;
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
       
        UpdateHealth();
    }

    // Update is called once per frame
    void Update() {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        if (restart == true)
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
        }

        
        UpdateHealth();

    }


    void UpdateHealth()
    {
        if (winText.enabled == true)
        {
            healthText.text = "YAY";
        }
        else if (player.health > 0)
        {
            healthText.text = "Health: " + player.health;
        }
        else if (player.health == 0)
        {
            GameOver();
        
        }
    }


    public void GameOver()
    {
        
        gameOverText.enabled = true;
        restartText.enabled = true;
        restart = true;
        player.speed = 0;
        noKeyText.enabled = false;
        
        
    }
    
    public void Win()
    {
        winText.enabled = true;
        restartText.enabled = true;
        restart = true;
        player.speed = 0;
        noKeyText.enabled = false;
        
    }

    public void NoKey()
    {
        noKeyText.enabled = true;
    }

}
