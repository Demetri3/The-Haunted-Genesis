﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerWalking : MonoBehaviour {

    //declare variables
    private Animator animation;
    private Player player;
    

    // Use this for initialization
    void Start () {
        animation = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
        
        if(Input.GetKeyDown(KeyCode.W))
        {
            animation.Play("playerUp");
        }
		if(Input.GetKeyDown(KeyCode.A))
        {
            animation.Play("playerLeft");
        }
        if(Input.GetKeyDown(KeyCode.S))
        {
            animation.Play("playerDown");
        }
        if(Input.GetKeyDown(KeyCode.D))
        {
            animation.Play("playerRight");
        }
	}
}
