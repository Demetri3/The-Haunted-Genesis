﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

    public float speed;
    private Transform playerPos;
    private Player player;

   void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        playerPos = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

   void Update()
   {
        transform.position = Vector2.MoveTowards(transform.position, playerPos.position, speed * Time.deltaTime);    
   }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {// Losing Health
            player.health--;
            Debug.Log(player.health);
            Destroy(gameObject);
        }
        if (other.CompareTag("Projectile"))
        {
            Destroy(gameObject);
        }
    }

}
