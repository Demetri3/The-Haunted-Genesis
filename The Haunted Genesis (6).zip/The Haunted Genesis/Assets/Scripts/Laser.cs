﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser : MonoBehaviour {

    
    public GameObject laser;
    private Player player;

    private float timeBtw;
    public float start;

    // Use this for initialization
    void Start () {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        timeBtw = start;
    }
	
	// Update is called once per frame
	void Update () {
        if (timeBtw <= 0)
        {
            laser.SetActive(true);
              Debug.Log("help");
            
            timeBtw = 2;
        }
        else
        {

            laser.SetActive(false);
            timeBtw -= Time.deltaTime;
            
        }
        
    }
    

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {// Losing Health
            player.health--;
            Debug.Log(player.health);
            player.speed =0;
            
        }
        
    }
}
