﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//new using statements
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;

public class GameController : MonoBehaviour {

    [Header("UI setting")]
    public Text healthText;
    public Text noKeyText;
    public Image gameOverImage;
    public Image WinImage;

    private bool restart;
    
    private Player player;
    

    // Use this for initialization
    void Start() {
        gameOverImage.enabled = false;
        WinImage.enabled = false;
        restart = false;
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        
        UpdateHealth();
    }

    // Update is called once per frame
    void Update() {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        if (restart == true)
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
        }  
        
        UpdateHealth();

    }


    void UpdateHealth()
    {
        if (player.health > 0)
        {
            healthText.text = "Health: " + player.health;
        }
        else if (player.health == 0)
        {
            GameOver();
        
        }
    }


    public void GameOver()
    {
        
        restart = true;
        player.speed = 0;
        noKeyText.enabled = false;
        gameOverImage.enabled = true;
        
    }
    
    public void Win()
    {
       
        restart = true;
        player.speed = 0;
        noKeyText.enabled = false;
        WinImage.enabled = true;
    }

    public void NoKey()
    {
        noKeyText.enabled = true;
    }

}
