﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    private GameController gc;
    
    public int gotKey;
    public float speed;
    public int health = 10;
    private Rigidbody2D rb;
    private Vector2 moveVelocity;

    

    private void Start()
    {
        gotKey = 0;
        rb = GetComponent<Rigidbody2D>();
        GameObject GameControllerObject = GameObject.FindWithTag("GameController");
        if (GameControllerObject != null)
        {
            gc= GameControllerObject.GetComponent<GameController>();
        }
        if (gc == null)
        {
            Debug.Log("Cannot find gamecontroller script on game controller object");
        }
        
    }

    void Update()
    {
        Vector2 moveInput = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
        moveVelocity = moveInput.normalized * speed;


    }

    void FixedUpdate()
    {
        rb.MovePosition(rb.position + moveVelocity * Time.fixedDeltaTime);   
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Item"))
        {

            Destroy(other.gameObject);
            gotKey = 1;


        }

        if (other.gameObject.CompareTag("Win"))
        {
            if (gotKey == 1)
            {
                gc.Win();
            }
            else
            {
                gc.NoKey();
            }

        }
    }


}
